python -m tests.test_calculator
python -m tests.unittest_calculator

pip install --index-url https://test.pypi.org/simple/ NathanPham_calculator
