def add_complex(a, b):
    return a + b

def subtract_complex(a, b):
    return a - b
